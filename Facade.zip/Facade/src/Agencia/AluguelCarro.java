/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Agencia;

/**
 *
 * @author JéssicaFerreira
 */
public class AluguelCarro {
    
    private String modelo;
    private double valorDiaria;

    public AluguelCarro() {
        this.modelo = "Logam vermelho";
        this.valorDiaria = 1000;
    }

    @Override
    public String toString() {
        return "Carro alugado: \nModelo: " + this.modelo + "\nValor diaria: " + this.valorDiaria ;
    }
    
  //Getters & Setters  
    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public double getValorDiaria() {
        return valorDiaria;
    }

    public void setValorDiaria(double valorDiaria) {
        this.valorDiaria = valorDiaria;
    }   
    
}
