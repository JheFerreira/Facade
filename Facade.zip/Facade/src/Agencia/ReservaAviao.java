/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Agencia;

/**
 *
 * @author JéssicaFerreira
 */
public class ReservaAviao extends Reserva{
    private String nomeEmpresa;

    public ReservaAviao(String data) {
        super(data, 600);
        this.nomeEmpresa = "Latam";
    }
    
     @Override
    public String toString() {
        return "Companhia Áerea : \nNome:" + this.getNomeEmpresa() + " \nValor: " + this.getValor();
    }
    
  //Getters & Setters
    public String getNomeEmpresa() {
        return nomeEmpresa;
    }

    public void setNomeEmpresa(String nomeEmpresa) {
        this.nomeEmpresa = nomeEmpresa;
    }
    
}
